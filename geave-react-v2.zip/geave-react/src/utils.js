import { COORDS } from './constants';

export const fmtDate = (d) => {
  if (!d) return '—';
  const [y, m, dd] = d.split('-');
  return `${dd}/${m}/${y}`;
};

export const fmtTs = (iso) => {
  const d = new Date(iso);
  return (
    d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) +
    ' ' +
    d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  );
};

export const initials = (n) =>
  n.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2);

export const isOverdue = (t) => {
  if (!t.deadline || t.status === 'concluido') return false;
  return new Date(t.deadline) < new Date(new Date().toDateString());
};

export const isNear = (t) => {
  if (!t.deadline || t.status === 'concluido') return false;
  const d = (new Date(t.deadline) - new Date()) / 86400000;
  return d >= 0 && d <= 3;
};

export const ci = (name) => COORDS[name] || { cell: '', email: '', av: 'av-X', wa: '' };

export const statusLabel = (s) =>
  s === 'nao_iniciado' ? 'Não Iniciado'
  : s === 'andamento'  ? 'Em Andamento'
  : s === 'concluido'  ? 'Concluído'
  : '—';

export const prioOrder = (p) => (p === 'alta' ? 0 : p === 'media' ? 1 : 2);

export const getWeekBounds = () => {
  const now = new Date();
  const day = now.getDay();
  const mon = new Date(now);
  mon.setDate(now.getDate() - (day === 0 ? 6 : day - 1));
  mon.setHours(0, 0, 0, 0);
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  sun.setHours(23, 59, 59, 999);
  return { mon, sun };
};

export const prazoDiasStr = (deadline) => {
  const d = Math.ceil((new Date(deadline) - new Date()) / 86400000);
  if (d < 0)  return `ATRASADO há ${Math.abs(d)} dia(s)`;
  if (d === 0) return 'Vence HOJE';
  return `Vence em ${d} dia(s) · ${fmtDate(deadline)}`;
};

export const buildMailto = (t) => {
  const cinfo = ci(t.resp);
  if (!cinfo.email) return '';
  const prazoStr = prazoDiasStr(t.deadline);
  const subj = encodeURIComponent(t.title);
  const body = encodeURIComponent(
    `Olá, ${t.resp}!\n\nUma nova atividade foi atribuída a você no sistema Geave - Pamcary.\n\n📋 ${t.title}\n\n` +
    `${t.desc ? `Descrição:\n${t.desc}\n\n` : ''}` +
    `📅 Prazo: ${fmtDate(t.deadline)} · ${prazoStr}\n🔴 Prioridade: ${t.prio.toUpperCase()}\n\n` +
    `Por favor, acesse o sistema e atualize o status conforme o andamento.\n\nAtenciosamente,`
  );
  return `mailto:${cinfo.email}?subject=${subj}&body=${body}`;
};

export const exportXLSX = (tasks, isOverdueFn, statusLabelFn, ciInfo, fmtDateFn) => {
  const filtered = tasks;
  if (!filtered.length) return false;

  const doExport = () => {
    const wb = window.XLSX.utils.book_new();
    const data = [['Título','Coordenador','Célula','Prioridade','Status','Prazo','Atrasado','Descrição']];
    filtered.forEach(t => {
      const c = ciInfo(t.resp);
      data.push([t.title, t.resp, c.cell, t.prio, statusLabelFn(t.status), fmtDateFn(t.deadline), isOverdueFn(t) ? 'Sim' : 'Não', t.desc || '']);
    });
    const ws = window.XLSX.utils.aoa_to_sheet(data);
    ws['!cols'] = [{wch:40},{wch:15},{wch:18},{wch:10},{wch:16},{wch:12},{wch:10},{wch:50}];
    window.XLSX.utils.book_append_sheet(wb, ws, 'Atividades');
    window.XLSX.writeFile(wb, `atividades_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  if (typeof window.XLSX !== 'undefined') {
    doExport();
  } else {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
    s.onload = doExport;
    document.head.appendChild(s);
  }
  return true;
};
