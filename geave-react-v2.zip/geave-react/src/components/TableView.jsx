import React from 'react';
import { fmtDate, isOverdue, statusLabel, ci, initials, buildMailto } from '../utils';
import { AV_COLORS, COORDS } from '../constants';
import { useApp } from '../context/AppContext';

const PC = { alta:'#ef4444', media:'#f59e0b', baixa:'#10b981' };
const SC = { nao_iniciado:'#f59e0b', andamento:'#3b82f6', concluido:'#10b981' };

export default function TableView({ tasks, role, onOpen, onEdit, onDelete, onNotify }) {
  const { showToast } = useApp();

  return (
    <div style={S.wrap}>
      <table style={S.table}>
        <thead>
          <tr>
            {['Atividade','Coordenador','Célula','Prioridade','Status','Prazo','Ações'].map(h=>(
              <th key={h} style={S.th}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {tasks.length === 0 ? (
            <tr><td colSpan={7} style={S.empty}>Nenhuma atividade encontrada</td></tr>
          ) : tasks.map(t => {
            const cinfo   = ci(t.resp);
            const avColor = AV_COLORS[COORDS[t.resp]?.av || 'av-X'];
            const over    = isOverdue(t);
            const waMsg   = encodeURIComponent(`Olá, ${t.resp}! Gostaria de falar sobre a tarefa: ${t.title}`);
            const waUrl   = cinfo.wa ? `https://wa.me/${cinfo.wa}?text=${waMsg}` : '';
            return (
              <tr key={t.id} style={S.tr} onClick={()=>onOpen(t.id)}>
                <td style={S.td}>
                  <div style={S.taskTitle}>{t.title}</div>
                  {t.desc && <div style={S.taskDesc}>{t.desc.slice(0,60)}{t.desc.length>60?'…':''}</div>}
                </td>
                <td style={S.td}>
                  <div style={S.coordCell}>
                    <div style={{...S.avatar,background:avColor}}>{initials(t.resp)}</div>
                    <span style={S.respName}>{t.resp}</span>
                  </div>
                </td>
                <td style={{...S.td,color:'#6b7a99',fontSize:13}}>{cinfo.cell}</td>
                <td style={S.td}><span style={{...S.tag,background:PC[t.prio]+'18',color:PC[t.prio]}}>{t.prio.toUpperCase()}</span></td>
                <td style={S.td}><span style={{...S.tag,background:SC[t.status]+'18',color:SC[t.status]}}>{statusLabel(t.status)}</span></td>
                <td style={{...S.td,color:over?'#ef4444':'#6b7a99',fontSize:13,fontWeight:over?600:400}}>{over?'⚠️ ':''}{fmtDate(t.deadline)}</td>
                <td style={S.td} onClick={e=>e.stopPropagation()}>
                  <div style={S.btnRow}>
                    {role==='gestao' && (
                      <>
                        <button style={S.tblBtn} onClick={()=>onNotify(t.id)} title="Notificar">✉️ Notificar</button>
                        {waUrl && <a style={{...S.tblBtn,textDecoration:'none',color:'#25d366'}} href={waUrl} target="_blank" rel="noreferrer">💬 WA</a>}
                        <button style={S.tblBtn} onClick={()=>onEdit(t.id)}>✏️ Editar</button>
                        <button style={{...S.tblBtn,...S.delTbl}} onClick={()=>onDelete(t.id)}>🗑 Excluir</button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

const S = {
  wrap: { background:'#fff',borderRadius:18,border:'1px solid rgba(0,0,0,.08)',overflow:'hidden' },
  table: { width:'100%',borderCollapse:'collapse',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  th: { padding:'13px 14px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'1px',color:'#6b7a99',borderBottom:'1px solid rgba(0,0,0,.06)',background:'#f5f7fb',whiteSpace:'nowrap' },
  tr: { cursor:'pointer',transition:'background .15s' },
  td: { padding:'13px 14px',borderBottom:'1px solid rgba(0,0,0,.04)',verticalAlign:'middle' },
  taskTitle: { fontFamily:"'Clash Display',sans-serif",fontSize:13.5,fontWeight:600,color:'#1a2035' },
  taskDesc: { fontSize:12,color:'#9aa3b8',marginTop:3 },
  coordCell: { display:'flex',alignItems:'center',gap:8 },
  avatar: { width:26,height:26,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:10,fontWeight:700,flexShrink:0 },
  respName: { fontSize:13,fontWeight:500,color:'#1a2035' },
  tag: { fontSize:11,fontWeight:700,padding:'4px 10px',borderRadius:20,letterSpacing:'.3px' },
  empty: { padding:40,textAlign:'center',color:'#9aa3b8',fontSize:14 },
  btnRow: { display:'flex',gap:5,flexWrap:'wrap' },
  tblBtn: { padding:'5px 10px',border:'1px solid rgba(0,0,0,.1)',borderRadius:7,background:'#f5f7fb',color:'#6b7a99',fontSize:11.5,fontWeight:500,cursor:'pointer',fontFamily:"'Plus Jakarta Sans',sans-serif',transition:'all .15s',whiteSpace:'nowrap'" },
  delTbl: { color:'#ef4444',borderColor:'rgba(239,68,68,.25)',background:'rgba(239,68,68,.05)' },
};
