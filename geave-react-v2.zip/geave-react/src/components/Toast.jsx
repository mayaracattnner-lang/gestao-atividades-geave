import React from 'react';
import { useApp } from '../context/AppContext';

export default function Toast() {
  const { toast } = useApp();
  return (
    <div style={{
      position: 'fixed', bottom: 28, left: '50%', transform: `translateX(-50%) translateY(${toast ? 0 : 80}px)`,
      background: '#1a2035', borderRadius: 12, padding: '12px 20px',
      display: 'flex', alignItems: 'center', gap: 10, zIndex: 9999,
      boxShadow: '0 8px 30px rgba(0,0,0,.25)', transition: 'transform .3s cubic-bezier(.34,1.56,.64,1)',
      fontFamily: "'Plus Jakarta Sans',sans-serif", minWidth: 220,
    }}>
      <div style={{ width: 8, height: 8, borderRadius: '50%', background: toast?.color || '#10b981', flexShrink: 0 }} />
      <span style={{ color: '#fff', fontSize: 13, fontWeight: 500 }}>{toast?.msg || ''}</span>
    </div>
  );
}
