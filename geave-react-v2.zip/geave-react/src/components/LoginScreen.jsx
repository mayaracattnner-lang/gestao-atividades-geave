import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GESTAO_EMAIL, GESTAO_PASS, COORD_PASS, COORD_EMAILS } from '../constants';

export default function LoginScreen() {
  const { login, appLoading } = useApp();
  const [email,    setEmail]    = useState('');
  const [pass,     setPass]     = useState('');
  const [remember, setRemember] = useState(false);
  const [error,    setError]    = useState(false);
  const [loading,  setLoading]  = useState(false);

  const doLogin = async () => {
    setError(false);
    setLoading(true);
    const e = email.trim().toLowerCase();
    if (e === GESTAO_EMAIL.toLowerCase() && pass === GESTAO_PASS) {
      await login('gestao', null, remember);
      return;
    }
    const coordName = COORD_EMAILS[e];
    if (coordName && pass === COORD_PASS) {
      await login('coordenador', coordName, remember);
      return;
    }
    setError(true);
    setPass('');
    setLoading(false);
  };

  const busy = loading || appLoading;

  return (
    <div style={S.wrap}>
      <div style={S.box}>
        <div style={S.logo}>
          <div style={S.icon}>📋</div>
          <div>
            <div style={S.logoText}>Ativ<span style={{color:'#3b82f6'}}>.</span>Gestão</div>
            <div style={S.logoSub}>Geave - Pamcary</div>
          </div>
        </div>
        <div style={S.title}>Acesso ao Sistema</div>
        <div style={S.sub}>Entre com seu e-mail e senha para continuar</div>
        {error && <div style={S.err}>E-mail ou senha incorretos.</div>}
        <label style={S.label}>E-mail</label>
        <input style={S.input} type="email" placeholder="seu@email.com" value={email} onChange={e=>setEmail(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doLogin()} disabled={busy} />
        <label style={S.label}>Senha</label>
        <input style={S.input} type="password" placeholder="••••••••" value={pass} onChange={e=>setPass(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doLogin()} disabled={busy} />
        <label style={S.remember}>
          <input type="checkbox" checked={remember} onChange={e=>setRemember(e.target.checked)} style={{width:16,height:16}} />
          <span style={{fontSize:13,color:'#6b7a99'}}>Lembrar acesso neste dispositivo</span>
        </label>
        <button style={{...S.btn, opacity:busy?.7:1}} onClick={doLogin} disabled={busy}>
          {busy ? 'Carregando…' : 'Entrar'}
        </button>
      </div>
    </div>
  );
}

const S = {
  wrap: { position:'fixed',inset:0,background:'linear-gradient(135deg,#eef2ff,#f0f9ff)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  box:  { background:'#fff',border:'1px solid rgba(0,0,0,.12)',borderRadius:24,padding:'44px 40px',width:'100%',maxWidth:420,boxShadow:'0 20px 60px rgba(0,0,0,.12)' },
  logo: { display:'flex',alignItems:'center',gap:12,marginBottom:32 },
  icon: { width:44,height:44,borderRadius:12,background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:22 },
  logoText: { fontFamily:"'Clash Display',sans-serif",fontSize:22,fontWeight:700 },
  logoSub: { fontSize:12,color:'#6b7a99',marginTop:2 },
  title: { fontFamily:"'Clash Display',sans-serif",fontSize:18,fontWeight:700,marginBottom:6 },
  sub:   { fontSize:13,color:'#6b7a99',marginBottom:24 },
  err:   { background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.3)',borderRadius:9,padding:'10px 14px',fontSize:13,color:'#ef4444',marginBottom:14 },
  label: { display:'block',fontSize:12,fontWeight:600,color:'#1a2035',marginBottom:6,marginTop:14 },
  input: { width:'100%',padding:'10px 14px',border:'1px solid rgba(0,0,0,.14)',borderRadius:10,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",outline:'none',boxSizing:'border-box',background:'#f5f7fb' },
  remember: { display:'flex',alignItems:'center',gap:9,marginTop:16,cursor:'pointer',userSelect:'none' },
  btn: { width:'100%',marginTop:20,background:'linear-gradient(135deg,#3b82f6,#6366f1)',border:'none',borderRadius:10,padding:12,color:'#fff',fontFamily:"'Clash Display',sans-serif",fontSize:15,fontWeight:600,cursor:'pointer',boxShadow:'0 4px 15px rgba(59,130,246,.3)' },
};
