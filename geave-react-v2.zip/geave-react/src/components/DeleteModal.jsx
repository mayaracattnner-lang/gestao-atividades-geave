import React from 'react';
import { useApp } from '../context/AppContext';

export default function DeleteModal({ taskId, onClose }) {
  const { tasks, deleteTask, showToast } = useApp();
  const task = tasks.find(t => t.id === taskId);
  if (!task) return null;

  const confirm = () => {
    deleteTask(taskId);
    showToast('Atividade excluída.', '#ef4444');
    onClose();
  };

  return (
    <div style={S.overlay} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={S.modal}>
        <div style={S.icon}>🗑️</div>
        <div style={S.title}>Excluir atividade?</div>
        <div style={S.msg}>Tem certeza que deseja excluir <strong>"{task.title}"</strong> atribuída a {task.resp}? Essa ação não pode ser desfeita.</div>
        <div style={S.actions}>
          <button style={S.cancelBtn} onClick={onClose}>Cancelar</button>
          <button style={S.delBtn} onClick={confirm}>Sim, excluir</button>
        </div>
      </div>
    </div>
  );
}

const S = {
  overlay: { position:'fixed',inset:0,background:'rgba(0,0,0,.45)',backdropFilter:'blur(8px)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  modal: { background:'#fff',borderRadius:20,padding:40,width:'100%',maxWidth:420,textAlign:'center',boxShadow:'0 24px 80px rgba(0,0,0,.25)' },
  icon:  { fontSize:44,marginBottom:16 },
  title: { fontFamily:"'Clash Display',sans-serif",fontSize:20,fontWeight:700,color:'#ef4444',marginBottom:12 },
  msg:   { fontSize:14,color:'#6b7a99',lineHeight:1.6,marginBottom:28 },
  actions: { display:'flex',gap:12,justifyContent:'center' },
  cancelBtn: { padding:'10px 24px',border:'1px solid rgba(0,0,0,.12)',borderRadius:10,background:'transparent',color:'#6b7a99',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:14,cursor:'pointer' },
  delBtn:    { padding:'10px 24px',border:'none',borderRadius:10,background:'#ef4444',color:'#fff',fontFamily:"'Clash Display',sans-serif",fontSize:14,fontWeight:600,cursor:'pointer' },
};
