import React from 'react';
import { isOverdue } from '../utils';

export default function StatsGrid({ tasks }) {
  const total    = tasks.length;
  const ni       = tasks.filter(t => t.status === 'nao_iniciado').length;
  const an       = tasks.filter(t => t.status === 'andamento').length;
  const co       = tasks.filter(t => t.status === 'concluido').length;
  const at       = tasks.filter(t => isOverdue(t)).length;

  const stats = [
    { label:'Total',        value:total, color:'#8b5cf6', icon:'📋' },
    { label:'Não Iniciado', value:ni,    color:'#f59e0b', icon:'⏸' },
    { label:'Em Andamento', value:an,    color:'#f97316', icon:'🔄' },
    { label:'Concluídas',   value:co,    color:'#10b981', icon:'✅' },
    { label:'Atrasadas',    value:at,    color:'#ef4444', icon:'⚠️' },
  ];

  return (
    <div style={S.grid}>
      {stats.map((s, i) => (
        <div key={i} style={{...S.card, borderColor:s.color+'33'}}>
          <div style={S.top}>
            <div style={{...S.iconWrap, background:s.color+'18'}}><span style={{fontSize:14}}>{s.icon}</span></div>
            <span style={S.label}>{s.label}</span>
          </div>
          <div style={{...S.num, color:s.color}}>{String(s.value).padStart(2,'0')}</div>
          <div style={S.bar}><div style={{...S.fill, background:s.color, width:total?`${(s.value/total)*100}%`:'0%'}}/></div>
        </div>
      ))}
    </div>
  );
}

const S = {
  grid: { display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:16,marginBottom:28 },
  card: { background:'#fff',border:'1px solid',borderRadius:18,padding:'22px 24px 18px',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  top:  { display:'flex',alignItems:'center',gap:8,marginBottom:10 },
  iconWrap: { width:28,height:28,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center' },
  label: { fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'1px',color:'#6b7a99' },
  num:  { fontFamily:"'Clash Display',sans-serif",fontSize:50,fontWeight:700,lineHeight:1,letterSpacing:'-3px' },
  bar:  { marginTop:14,height:3,borderRadius:3,background:'#eaecf4',overflow:'hidden' },
  fill: { height:'100%',borderRadius:3,transition:'width .8s cubic-bezier(.4,0,.2,1)' },
};
