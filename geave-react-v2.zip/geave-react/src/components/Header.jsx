import React from 'react';
import { useApp } from '../context/AppContext';
import { initials } from '../utils';
import { COORDS, AV_COLORS } from '../constants';

export default function Header({ view, setView }) {
  const { role, coordName, logout } = useApp();
  const avColor = coordName ? AV_COLORS[COORDS[coordName]?.av || 'av-X'] : null;

  return (
    <header style={S.header}>
      <div style={S.logo}>
        <div style={S.icon}>📋</div>
        <div>
          <div style={S.logoText}>Ativ<span style={{color:'#3b82f6'}}>.</span>Gestão</div>
          <div style={S.logoSub}>Geave - Pamcary</div>
        </div>
      </div>

      <div style={S.right}>
        {/* View switcher — always visible when logged in */}
        <div style={S.switcher}>
          <button style={{...S.switchBtn,...(view==='kanban'?S.switchActive:{})}} onClick={()=>setView('kanban')}>Kanban</button>
          <button style={{...S.switchBtn,...(view==='tabela'?S.switchActive:{})}} onClick={()=>setView('tabela')}>Tabela</button>
        </div>

        {/* Coord badge */}
        {role==='coordenador' && coordName && (
          <div style={S.coordBadge}>
            <div style={{...S.avatar,background:avColor}}>{initials(coordName)}</div>
            <span style={S.coordName}>{coordName}</span>
          </div>
        )}

        <button style={S.logoutBtn} onClick={logout}>Sair</button>
      </div>
    </header>
  );
}

const S = {
  header: { position:'sticky',top:0,zIndex:200,background:'rgba(255,255,255,.92)',borderBottom:'1px solid rgba(0,0,0,.08)',backdropFilter:'blur(20px)',padding:'0 32px',height:64,display:'flex',alignItems:'center',justifyContent:'space-between',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  logo: { display:'flex',alignItems:'center',gap:10 },
  icon: { width:32,height:32,borderRadius:8,background:'linear-gradient(135deg,#3b82f6,#8b5cf6)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:15 },
  logoText: { fontFamily:"'Clash Display',sans-serif",fontSize:18,fontWeight:700,letterSpacing:'-0.3px' },
  logoSub: { color:'#6b7a99',fontSize:11,marginTop:1 },
  right: { display:'flex',alignItems:'center',gap:12 },
  switcher: { display:'flex',background:'#f5f7fb',border:'1px solid rgba(0,0,0,.08)',borderRadius:10,padding:3,gap:2 },
  switchBtn: { padding:'6px 16px',borderRadius:7,border:'none',cursor:'pointer',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,fontWeight:500,color:'#6b7a99',background:'transparent',transition:'all .2s' },
  switchActive: { background:'#eaecf4',color:'#1a2035',boxShadow:'0 1px 3px rgba(0,0,0,.15)' },
  coordBadge: { display:'flex',alignItems:'center',gap:7 },
  avatar: { width:28,height:28,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:11,fontWeight:700 },
  coordName: { fontSize:14,fontWeight:500,color:'#1a2035' },
  logoutBtn: { padding:'6px 14px',borderRadius:8,border:'1px solid rgba(0,0,0,.08)',background:'transparent',color:'#6b7a99',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:12,cursor:'pointer' },
};
