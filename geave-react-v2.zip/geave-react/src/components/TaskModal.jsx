import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { COORDS } from '../constants';
import { fmtDate, ci, prazoDiasStr } from '../utils';

export default function TaskModal({ taskId, onClose }) {
  const { tasks, createTask, updateTask, role, coordName, showToast } = useApp();
  const editing = taskId ? tasks.find(t => t.id === taskId) : null;

  const [title,    setTitle]    = useState(editing?.title    || '');
  const [desc,     setDesc]     = useState(editing?.desc     || '');
  const [resp,     setResp]     = useState(editing?.resp     || Object.keys(COORDS)[0]);
  const [deadline, setDeadline] = useState(editing?.deadline || '');
  const [prio,     setPrio]     = useState(editing?.prio     || 'media');
  const [status,   setStatus]   = useState(editing?.status   || 'nao_iniciado');
  const [err,      setErr]      = useState('');

  const validate = () => {
    if (!title.trim()) { setErr('O título é obrigatório.'); return false; }
    if (!deadline)     { setErr('O prazo é obrigatório.');  return false; }
    return true;
  };

  const save = (andNotify = false) => {
    if (!validate()) return;
    const data = { title:title.trim(), desc:desc.trim(), resp, deadline, prio, status: editing ? status : 'nao_iniciado' };

    if (editing) {
      updateTask(editing.id, data, role, coordName);
      showToast('✅ Atividade atualizada!', '#10b981');
    } else {
      const newTask = createTask(data);
      if (andNotify) {
        const cinfo     = ci(resp);
        const prazoStr  = prazoDiasStr(deadline);
        const subj      = encodeURIComponent(title);
        const body      = encodeURIComponent(
          `Olá, ${resp}!\n\nUma nova atividade foi atribuída a você no sistema Geave - Pamcary.\n\n📋 ${title}\n\n` +
          `${desc ? `Descrição:\n${desc}\n\n` : ''}📅 Prazo: ${fmtDate(deadline)} · ${prazoStr}\n🔴 Prioridade: ${prio.toUpperCase()}\n\n` +
          `Por favor, acesse o sistema e atualize o status conforme o andamento.\n\nAtenciosamente,`
        );
        const a = document.createElement('a');
        a.href = `mailto:${cinfo.email}?subject=${subj}&body=${body}`;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        showToast('✅ Atividade criada e e-mail aberto!', '#10b981');
      } else {
        showToast('✅ Atividade criada!', '#10b981');
      }
    }
    onClose();
  };

  return (
    <div style={S.overlay} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={S.modal}>
        <div style={S.head}>
          <span style={S.title}>{editing ? 'Editar Atividade' : 'Nova Atividade'}</span>
          <button style={S.closeBtn} onClick={onClose}>✕</button>
        </div>

        {err && <div style={S.err}>{err}</div>}

        <label style={S.label}>Título *</label>
        <input style={S.input} value={title} onChange={e=>setTitle(e.target.value)} placeholder="Ex: Entregar relatório mensal" />

        <label style={S.label}>Descrição</label>
        <textarea style={{...S.input,height:72,resize:'vertical'}} value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Detalhes, contexto…" />

        <div style={S.row}>
          <div style={{flex:1}}>
            <label style={S.label}>Responsável</label>
            <select style={S.input} value={resp} onChange={e=>setResp(e.target.value)}>
              {Object.keys(COORDS).map(n=><option key={n} value={n}>{n} — {COORDS[n].cell}</option>)}
            </select>
          </div>
          <div style={{flex:1}}>
            <label style={S.label}>Prazo *</label>
            <input style={S.input} type="date" value={deadline} onChange={e=>setDeadline(e.target.value)} />
          </div>
        </div>

        <div style={S.row}>
          <div style={{flex:1}}>
            <label style={S.label}>Prioridade</label>
            <select style={S.input} value={prio} onChange={e=>setPrio(e.target.value)}>
              <option value="alta">Alta</option>
              <option value="media">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>
          {editing && (
            <div style={{flex:1}}>
              <label style={S.label}>Status</label>
              <select style={S.input} value={status} onChange={e=>setStatus(e.target.value)}>
                <option value="nao_iniciado">Não Iniciado</option>
                <option value="andamento">Em Andamento</option>
                <option value="concluido">Concluído</option>
              </select>
            </div>
          )}
        </div>

        <div style={S.footer}>
          <button style={S.cancelBtn} onClick={onClose}>Cancelar</button>
          {!editing && resp && (
            <button style={{...S.saveBtn, background:'#f97316'}} onClick={()=>save(true)}>
              ✉️ Criar e notificar
            </button>
          )}
          <button style={S.saveBtn} onClick={()=>save(false)}>
            {editing ? 'Salvar alterações' : 'Criar atividade'}
          </button>
        </div>
      </div>
    </div>
  );
}

const S = {
  overlay: { position:'fixed',inset:0,background:'rgba(0,0,0,.45)',backdropFilter:'blur(6px)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:20,fontFamily:"'Plus Jakarta Sans',sans-serif" },
  modal: { background:'#fff',borderRadius:20,padding:32,width:'100%',maxWidth:560,maxHeight:'90vh',overflowY:'auto',boxShadow:'0 24px 80px rgba(0,0,0,.25)' },
  head:  { display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:24 },
  title: { fontFamily:"'Clash Display',sans-serif",fontSize:20,fontWeight:700 },
  closeBtn: { background:'transparent',border:'none',fontSize:18,cursor:'pointer',color:'#6b7a99' },
  err:   { background:'rgba(239,68,68,.1)',border:'1px solid rgba(239,68,68,.3)',borderRadius:9,padding:'10px 14px',fontSize:13,color:'#ef4444',marginBottom:14 },
  label: { display:'block',fontSize:12,fontWeight:600,color:'#1a2035',marginBottom:6,marginTop:14 },
  input: { width:'100%',padding:'10px 14px',border:'1px solid rgba(0,0,0,.14)',borderRadius:10,fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif",outline:'none',boxSizing:'border-box',background:'#f5f7fb' },
  row:   { display:'flex',gap:16 },
  footer: { display:'flex',gap:10,marginTop:28,justifyContent:'flex-end',paddingTop:20,borderTop:'1px solid rgba(0,0,0,.06)' },
  cancelBtn: { padding:'10px 20px',border:'1px solid rgba(0,0,0,.12)',borderRadius:10,background:'transparent',color:'#6b7a99',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:14,cursor:'pointer' },
  saveBtn: { padding:'10px 24px',border:'none',borderRadius:10,background:'linear-gradient(135deg,#3b82f6,#6366f1)',color:'#fff',fontFamily:"'Clash Display',sans-serif",fontSize:14,fontWeight:600,cursor:'pointer' },
};
