import React from 'react';
import { fmtDate, isOverdue, isNear, ci, statusLabel, initials, buildMailto } from '../utils';
import { AV_COLORS, COORDS } from '../constants';

const PRIO_COLOR   = { alta:'#ef4444', media:'#f59e0b', baixa:'#10b981' };
const STATUS_COLOR = { nao_iniciado:'#f59e0b', andamento:'#3b82f6', concluido:'#10b981' };

export default function TaskCard({ task: t, role, onOpen, onEdit, onDelete, onNotify }) {
  const over    = isOverdue(t);
  const near    = isNear(t);
  const cinfo   = ci(t.resp);
  const avColor = AV_COLORS[COORDS[t.resp]?.av || 'av-X'];
  const waMsg   = encodeURIComponent(`Olá, ${t.resp}! Gostaria de falar sobre a tarefa: ${t.title}`);
  const waUrl   = cinfo.wa ? `https://wa.me/${cinfo.wa}?text=${waMsg}` : '';

  return (
    <div style={{...S.card, borderLeftColor: PRIO_COLOR[t.prio]}} onClick={() => onOpen(t.id)}>
      {/* Top row */}
      <div style={S.topRow}>
        <span style={{...S.prioTag, background:PRIO_COLOR[t.prio]+'18', color:PRIO_COLOR[t.prio]}}>{t.prio.toUpperCase()}</span>
        <div style={S.actions} onClick={e=>e.stopPropagation()}>
          {role==='gestao' && (
            <>
              <button style={S.actionBtn} title="Notificar" onClick={()=>onNotify(t.id)}>✉️</button>
              {waUrl && <a style={S.actionBtn} href={waUrl} target="_blank" rel="noreferrer" title={`WhatsApp ${t.resp}`}>💬</a>}
              <button style={S.actionBtn} title="Editar"  onClick={()=>onEdit(t.id)}>✏️</button>
              <button style={{...S.actionBtn,...S.delBtn}} title="Excluir" onClick={()=>onDelete(t.id)}>🗑</button>
            </>
          )}
        </div>
      </div>

      {/* Title */}
      <div style={S.title}>{t.title}</div>
      {t.desc && <div style={S.desc}>{t.desc}</div>}

      {/* Footer */}
      <div style={S.footer}>
        <div style={S.resp}>
          <div style={{...S.avatar, background:avColor}}>{initials(t.resp)}</div>
          <div>
            <div style={S.respName}>{t.resp}</div>
            <div style={S.respCell}>{cinfo.cell}</div>
          </div>
        </div>
        <div style={{...S.deadline, color: over?'#ef4444':near?'#f59e0b':'#6b7a99'}}>
          {over?'⚠️ ':near?'⏰ ':'📅 '}{fmtDate(t.deadline)}
        </div>
      </div>

      <span style={{...S.statusPill, background:STATUS_COLOR[t.status]}}>{statusLabel(t.status)}</span>
    </div>
  );
}

const S = {
  card: { background:'#fff',border:'1px solid rgba(0,0,0,.08)',borderLeft:'3px solid',borderRadius:14,padding:'14px 14px 12px',cursor:'pointer',fontFamily:"'Plus Jakarta Sans',sans-serif",marginBottom:10,transition:'box-shadow .2s' },
  topRow: { display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8 },
  prioTag: { fontSize:10,fontWeight:700,padding:'3px 9px',borderRadius:20,letterSpacing:'.5px' },
  actions: { display:'flex',gap:4 },
  actionBtn: { background:'rgba(0,0,0,.04)',border:'1px solid rgba(0,0,0,.08)',borderRadius:6,padding:'2px 6px',cursor:'pointer',fontSize:12,textDecoration:'none',transition:'all .15s' },
  delBtn: { },
  title: { fontFamily:"'Clash Display',sans-serif",fontSize:13.5,fontWeight:600,color:'#1a2035',marginBottom:5,lineHeight:1.4 },
  desc:  { fontSize:12,color:'#6b7a99',marginBottom:8,lineHeight:1.5,display:'-webkit-box',WebkitLineClamp:2,WebkitBoxOrient:'vertical',overflow:'hidden' },
  footer: { display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:10 },
  resp:   { display:'flex',alignItems:'center',gap:7 },
  avatar: { width:24,height:24,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:10,fontWeight:700,flexShrink:0 },
  respName: { fontSize:12,fontWeight:600,color:'#1a2035',lineHeight:1.2 },
  respCell: { fontSize:10,color:'#9aa3b8' },
  deadline: { fontSize:11,fontWeight:500 },
  statusPill: { marginTop:10,display:'inline-flex',alignItems:'center',fontSize:11,fontWeight:600,padding:'3px 10px',borderRadius:20,color:'#fff' },
};
