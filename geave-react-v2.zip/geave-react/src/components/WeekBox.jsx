import React from 'react';
import { getWeekBounds, fmtDate, isOverdue } from '../utils';

export default function WeekBox({ tasks, onOpen }) {
  const { mon, sun } = getWeekBounds();

  const weekTasks = tasks.filter(t => {
    if (!t.deadline) return false;
    const d = new Date(t.deadline);
    return d >= mon && d <= sun;
  }).sort((a, b) => (a.deadline > b.deadline ? 1 : -1));

  const monStr = mon.toLocaleDateString('pt-BR', { day:'2-digit', month:'2-digit' });
  const sunStr = sun.toLocaleDateString('pt-BR', { day:'2-digit', month:'2-digit' });

  const PRIO_COLOR = { alta:'#ef4444', media:'#f59e0b', baixa:'#10b981' };

  return (
    <div style={S.box}>
      <div style={S.head}>
        <div style={S.title}>📅 ATIVIDADES DESTA SEMANA</div>
        <div style={S.range}>{monStr} – {sunStr}</div>
      </div>
      {weekTasks.length === 0 ? (
        <div style={S.empty}>Nenhuma atividade com prazo nesta semana.</div>
      ) : (
        <div style={S.cards}>
          {weekTasks.map(t => (
            <div key={t.id} style={{...S.card, borderLeftColor: PRIO_COLOR[t.prio]}} onClick={() => onOpen(t.id)}>
              <div style={S.cardTitle}>{t.title}</div>
              <div style={S.cardMeta}>
                <span style={S.coordTag}>{t.resp}</span>
                <span style={{...S.deadlineTag, color: isOverdue(t)?'#ef4444':'#6b7a99'}}>{fmtDate(t.deadline)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const S = {
  box:   { background:'#fff',border:'1px solid rgba(6,182,212,.3)',borderRadius:18,padding:'22px 26px',marginBottom:28 },
  head:  { display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18 },
  title: { fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:700,textTransform:'uppercase',letterSpacing:'1.5px',color:'#06b6d4',display:'flex',alignItems:'center',gap:8 },
  range: { fontSize:12,color:'#6b7a99',background:'#f5f7fb',border:'1px solid rgba(0,0,0,.08)',borderRadius:8,padding:'4px 12px' },
  cards: { display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12 },
  card:  { background:'#f5f7fb',border:'1px solid rgba(0,0,0,.06)',borderLeft:'3px solid',borderRadius:12,padding:'14px 16px',cursor:'pointer',transition:'all .2s',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  cardTitle: { fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:600,color:'#1a2035',marginBottom:8,lineHeight:1.4 },
  cardMeta:  { display:'flex',alignItems:'center',justifyContent:'space-between',gap:6 },
  coordTag:  { fontSize:11,color:'#6b7a99',fontWeight:500 },
  deadlineTag: { fontSize:11,fontWeight:600 },
  empty: { textAlign:'center',padding:'24px 0',color:'#9aa3b8',fontSize:13 },
};
