import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { fmtDate, fmtTs, statusLabel, ci, initials, isOverdue, isNear, buildMailto, prazoDiasStr } from '../utils';
import { AV_COLORS, COORDS, CLAUDIA_WA } from '../constants';

const SC = { nao_iniciado:'#6b7a99', andamento:'#f97316', concluido:'#10b981' };
const PC = { alta:'#ef4444', media:'#f59e0b', baixa:'#10b981' };

export default function DetailModal({ taskId, onClose, onEdit }) {
  const { tasks, historyLog, comments, updateStatus, addComment, role, coordName, showToast } = useApp();
  const [commentText, setCommentText] = useState('');
  const task = tasks.find(t => t.id === taskId);
  if (!task) return null;

  const t       = task;
  const cinfo   = ci(t.resp);
  const avColor = AV_COLORS[COORDS[t.resp]?.av || 'av-X'];
  const hist    = historyLog[taskId] || [];
  const comms   = comments[taskId]   || [];
  const over    = isOverdue(t);
  const near    = isNear(t);
  const prazo   = t.deadline ? prazoDiasStr(t.deadline) : '—';

  // Notify
  const mailto  = buildMailto(t);
  const waMsg   = encodeURIComponent(`Olá, ${t.resp}! Gostaria de falar sobre a tarefa: ${t.title}`);
  const waUrl   = cinfo.wa ? `https://wa.me/${cinfo.wa}?text=${waMsg}` : '';

  // Coord → Claudia WA
  const waCoor  = encodeURIComponent(`Olá, Claudia! Gostaria de falar sobre a tarefa: ${t.title}`);
  const waClaudia = `https://wa.me/${CLAUDIA_WA}?text=${waCoor}`;

  const handleStatus = (s) => {
    updateStatus(taskId, s, role, coordName);
    showToast(`✅ Status: ${statusLabel(s)}`, '#10b981');
  };

  const handleComment = () => {
    if (!commentText.trim()) return;
    addComment(taskId, commentText.trim(), role, coordName);
    setCommentText('');
    showToast('Comentário adicionado!', '#10b981');
  };

  return (
    <div style={S.overlay} onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={S.modal}>
        {/* Head */}
        <div style={S.head}>
          <div style={{flex:1}}>
            <div style={S.titleText}>{t.title}</div>
            <div style={S.meta}>
              <div style={{...S.avatar, background:avColor}}>{initials(t.resp)}</div>
              <span>{t.resp} · {cinfo.cell}</span>
              <span style={{...S.prio, background:PC[t.prio]+'18', color:PC[t.prio]}}>{t.prio.toUpperCase()}</span>
              <span style={{...S.statusBadge, background:SC[t.status]+'18', color:SC[t.status]}}>{statusLabel(t.status)}</span>
            </div>
            <div style={{...S.prazoRow, color:over?'#ef4444':near?'#f59e0b':'#6b7a99'}}>
              📅 {fmtDate(t.deadline)}{t.deadline && ` · ${prazo}`}{over?' ⚠️':''}
            </div>
          </div>
          <button style={S.closeBtn} onClick={onClose}>✕</button>
        </div>

        {t.desc && <p style={S.desc}>{t.desc}</p>}

        {/* ── STATUS: coordenador atualiza ── */}
        {role === 'coordenador' && (
          <div style={S.section}>
            <div style={S.secLabel}>Atualizar Status</div>
            <div style={S.statusGrid}>
              {[['nao_iniciado','⬜','Não Iniciado'],['andamento','🔄','Em Andamento'],['concluido','✅','Concluído']].map(([k,ic,lb])=>(
                <div key={k}
                  style={{...S.statusChoice, ...(t.status===k?{border:`2px solid ${SC[k]}`,background:SC[k]+'12'}:{})}}
                  onClick={()=>handleStatus(k)}>
                  <span style={{fontSize:20}}>{ic}</span>
                  <span style={{fontSize:12,fontWeight:600,color:t.status===k?SC[k]:'#6b7a99'}}>{lb}</span>
                </div>
              ))}
            </div>
            {/* Coordenador fala com Claudia */}
            <div style={{...S.notifyPanel, borderColor:'rgba(37,211,102,.22)',marginTop:16}}>
              <div style={{...S.notifyTitle, color:'#25d366'}}>💬 Falar com Gestora</div>
              <div style={S.notifyPreview}><strong>Para:</strong> Claudia (Gestão)<br/><strong>Assunto:</strong> {t.title}</div>
              <a style={{...S.notifyBtn, background:'rgba(37,211,102,.12)',borderColor:'rgba(37,211,102,.3)',color:'#25d366'}}
                href={waClaudia} target="_blank" rel="noreferrer"
                onClick={()=>showToast('Abrindo WhatsApp…','#25d366')}>
                💬 WhatsApp Claudia
              </a>
            </div>
          </div>
        )}

        {/* ── NOTIFY: gestão ── */}
        {role === 'gestao' && cinfo.email && (
          <div style={S.section}>
            <div style={S.secLabel}>Notificar Responsável</div>
            <div style={S.notifyPanel}>
              <div style={S.notifyTitle}>✉️ Notificar Responsável</div>
              <div style={S.notifyPreview}>
                <strong>Para:</strong> {cinfo.email}<br/>
                <strong>Prazo:</strong> <span style={{color:over?'#ef4444':near?'#f59e0b':'inherit'}}>{prazo}</span>
              </div>
              <a style={S.notifyBtn} href={mailto} onClick={()=>showToast('Abrindo e-mail…','#3b82f6')}>
                ✉️ E-mail para {t.resp}
              </a>
              {waUrl && (
                <a style={{...S.notifyBtn, background:'rgba(37,211,102,.12)',borderColor:'rgba(37,211,102,.3)',color:'#25d366',marginTop:8}}
                  href={waUrl} target="_blank" rel="noreferrer"
                  onClick={()=>showToast('Abrindo WhatsApp…','#25d366')}>
                  💬 WhatsApp {t.resp}
                </a>
              )}
            </div>
          </div>
        )}

        {/* ── COMENTÁRIOS ── */}
        <div style={S.section}>
          <div style={S.secLabel}>💬 Comentários ({comms.length})</div>
          {comms.length === 0 && <p style={{color:'#9aa3b8',fontSize:13,marginBottom:10}}>Nenhum comentário ainda.</p>}
          {comms.map((c, i) => (
            <div key={i} style={S.comment}>
              <div style={S.commentMeta}>
                <span style={S.commentAuthor}>{c.who}</span>
                <span style={S.commentTime}>{fmtTs(c.ts)}</span>
              </div>
              <div style={S.commentText}>{c.text}</div>
            </div>
          ))}
          <div style={S.commentInputRow}>
            <input style={S.commentInput} placeholder="Adicionar comentário…" value={commentText}
              onChange={e=>setCommentText(e.target.value)} onKeyDown={e=>e.key==='Enter'&&handleComment()} />
            <button style={S.commentBtn} onClick={handleComment}>Enviar</button>
          </div>
        </div>

        {/* ── HISTÓRICO ── */}
        {hist.length > 0 && (
          <div style={S.section}>
            <div style={S.secLabel}>🕑 Histórico de Alterações</div>
            {hist.map((h, i) => (
              <div key={i} style={S.histItem}>
                <div style={S.histDot} />
                <div style={{flex:1}}>
                  <strong style={{color:'#1a2035'}}>{h.who}</strong>
                  <span style={{color:'#6b7a99'}}> · {h.action}</span>
                </div>
                <span style={S.histTime}>{fmtTs(h.ts)}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── FOOTER ── */}
        <div style={S.foot}>
          {role === 'gestao' && (
            <button style={S.editBtn} onClick={()=>{ onEdit(taskId); onClose(); }}>✏️ Editar</button>
          )}
          <button style={S.closeFootBtn} onClick={onClose}>Fechar</button>
        </div>
      </div>
    </div>
  );
}

const S = {
  overlay: { position:'fixed',inset:0,background:'rgba(0,0,0,.45)',backdropFilter:'blur(8px)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:20,fontFamily:"'Plus Jakarta Sans',sans-serif" },
  modal: { background:'#fff',borderRadius:22,padding:32,width:'100%',maxWidth:600,maxHeight:'92vh',overflowY:'auto',boxShadow:'0 24px 80px rgba(0,0,0,.25)' },
  head:  { display:'flex',gap:16,marginBottom:14 },
  titleText: { fontFamily:"'Clash Display',sans-serif",fontSize:20,fontWeight:700,color:'#1a2035',marginBottom:8,lineHeight:1.3 },
  meta:  { display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',marginBottom:6 },
  avatar: { width:26,height:26,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:10,fontWeight:700,flexShrink:0 },
  prio:  { fontSize:10,fontWeight:700,padding:'2px 9px',borderRadius:20,letterSpacing:'.5px' },
  statusBadge: { fontSize:11,fontWeight:600,padding:'3px 10px',borderRadius:20 },
  prazoRow: { fontSize:13,fontWeight:500 },
  closeBtn: { background:'transparent',border:'none',fontSize:20,cursor:'pointer',color:'#6b7a99',flexShrink:0,alignSelf:'flex-start' },
  desc:  { fontSize:14,color:'#6b7a99',lineHeight:1.65,marginBottom:20 },
  section: { borderTop:'1px solid rgba(0,0,0,.06)',paddingTop:16,marginTop:16 },
  secLabel: { fontFamily:"'Clash Display',sans-serif",fontSize:12,fontWeight:700,color:'#1a2035',textTransform:'uppercase',letterSpacing:'.8px',marginBottom:12 },
  statusGrid: { display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10 },
  statusChoice: { display:'flex',flexDirection:'column',alignItems:'center',gap:6,padding:'12px 8px',border:'2px solid rgba(0,0,0,.08)',borderRadius:12,cursor:'pointer',transition:'all .2s' },
  notifyPanel: { background:'#f5f7fb',border:'1px solid rgba(59,130,246,.22)',borderRadius:13,padding:'16px 18px' },
  notifyTitle: { fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'1px',color:'#3b82f6',marginBottom:10 },
  notifyPreview: { fontSize:13,color:'#6b7a99',lineHeight:1.65,marginBottom:14 },
  notifyBtn: { display:'flex',alignItems:'center',justifyContent:'center',gap:7,padding:'11px 18px',border:'1px solid rgba(59,130,246,.3)',borderRadius:9,background:'rgba(59,130,246,.1)',color:'#3b82f6',fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:600,cursor:'pointer',textDecoration:'none',width:'100%',boxSizing:'border-box' },
  comment: { background:'#f5f7fb',borderRadius:10,padding:'10px 13px',marginBottom:8 },
  commentMeta: { display:'flex',justifyContent:'space-between',marginBottom:4 },
  commentAuthor: { fontWeight:700,fontSize:11,color:'#3b82f6' },
  commentTime:   { fontSize:11,color:'#9aa3b8' },
  commentText:   { fontSize:13,color:'#1a2035',lineHeight:1.55 },
  commentInputRow: { display:'flex',gap:8,marginTop:8 },
  commentInput: { flex:1,padding:'9px 13px',border:'1px solid rgba(0,0,0,.12)',borderRadius:9,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",outline:'none' },
  commentBtn: { padding:'9px 16px',borderRadius:9,background:'#3b82f6',border:'none',color:'#fff',fontFamily:"'Clash Display',sans-serif",fontSize:12,fontWeight:600,cursor:'pointer' },
  histItem: { display:'flex',gap:10,alignItems:'flex-start',fontSize:12,marginBottom:8,paddingLeft:4 },
  histDot:  { width:7,height:7,borderRadius:'50%',background:'#3b82f6',marginTop:4,flexShrink:0 },
  histTime: { color:'#9aa3b8',flexShrink:0,fontSize:11 },
  foot:  { display:'flex',gap:10,marginTop:24,justifyContent:'flex-end' },
  editBtn: { padding:'9px 18px',border:'1px solid rgba(0,0,0,.12)',borderRadius:10,background:'transparent',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,cursor:'pointer' },
  closeFootBtn: { padding:'9px 18px',border:'1px solid rgba(0,0,0,.12)',borderRadius:10,background:'transparent',color:'#6b7a99',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,cursor:'pointer' },
};
