import React from 'react';
import { COORDS } from '../constants';
import { exportXLSX, isOverdue, statusLabel, ci, fmtDate } from '../utils';
import { useApp } from '../context/AppContext';

export default function Toolbar({ role, filters, setFilters, onNew, filteredTasks }) {
  const { showToast } = useApp();
  const set = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const handleExport = () => {
    const ok = exportXLSX(filteredTasks, isOverdue, statusLabel, ci, fmtDate);
    if (!ok) showToast('Nenhuma atividade para exportar.', '#f59e0b');
    else showToast('XLSX exportado!', '#10b981');
  };

  return (
    <div style={S.wrap}>
      <div style={S.row}>
        {/* Search */}
        <input style={S.search} placeholder="🔍 Buscar atividade…" value={filters.search} onChange={e=>set('search',e.target.value)} />

        {/* Coord filter — only gestão */}
        {role === 'gestao' && (
          <select style={S.sel} value={filters.coord} onChange={e=>set('coord',e.target.value)}>
            <option value="">Todos os coordenadores</option>
            {Object.keys(COORDS).map(n=><option key={n} value={n}>{n}</option>)}
          </select>
        )}

        {/* Status */}
        <select style={S.sel} value={filters.status} onChange={e=>set('status',e.target.value)}>
          <option value="">Todos os status</option>
          <option value="nao_iniciado">Não Iniciado</option>
          <option value="andamento">Em Andamento</option>
          <option value="concluido">Concluído</option>
          <option value="atrasado">Atrasado</option>
        </select>

        {/* Priority */}
        <select style={S.sel} value={filters.prio} onChange={e=>set('prio',e.target.value)}>
          <option value="">Todas as prioridades</option>
          <option value="alta">Alta</option>
          <option value="media">Média</option>
          <option value="baixa">Baixa</option>
        </select>

        {/* Date range */}
        <input style={{...S.sel, minWidth:130}} type="date" value={filters.dateFrom} onChange={e=>set('dateFrom',e.target.value)} title="Prazo de" />
        <input style={{...S.sel, minWidth:130}} type="date" value={filters.dateTo}   onChange={e=>set('dateTo',e.target.value)}   title="Prazo até" />

        {/* Sort */}
        <select style={S.sel} value={filters.sort} onChange={e=>set('sort',e.target.value)}>
          <option value="prio">Ordenar: Prioridade</option>
          <option value="prazo">Ordenar: Prazo</option>
          <option value="criacao">Ordenar: Criação</option>
        </select>
      </div>

      <div style={S.actions}>
        <button style={S.exportBtn} onClick={handleExport}>📥 Exportar XLSX</button>
        {role === 'gestao' && (
          <button style={S.newBtn} onClick={onNew}>+ Nova Atividade</button>
        )}
      </div>
    </div>
  );
}

const S = {
  wrap: { marginBottom:20, display:'flex', flexDirection:'column', gap:10 },
  row:  { display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' },
  actions: { display:'flex', gap:10, justifyContent:'flex-end' },
  search: { padding:'9px 14px',border:'1px solid rgba(0,0,0,.1)',borderRadius:10,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",outline:'none',background:'#fff',minWidth:200,flex:1 },
  sel:   { padding:'9px 12px',border:'1px solid rgba(0,0,0,.1)',borderRadius:10,fontSize:13,fontFamily:"'Plus Jakarta Sans',sans-serif",outline:'none',background:'#fff',cursor:'pointer' },
  exportBtn: { padding:'9px 18px',border:'1px solid rgba(0,0,0,.1)',borderRadius:10,background:'#fff',color:'#6b7a99',fontFamily:"'Plus Jakarta Sans',sans-serif",fontSize:13,fontWeight:500,cursor:'pointer' },
  newBtn: { display:'flex',alignItems:'center',gap:7,padding:'10px 20px',background:'linear-gradient(135deg,#3b82f6,#6366f1)',border:'none',borderRadius:10,color:'#fff',fontFamily:"'Clash Display',sans-serif",fontSize:14,fontWeight:600,cursor:'pointer',whiteSpace:'nowrap',boxShadow:'0 4px 15px rgba(59,130,246,.3)' },
};
