import React, { useState } from 'react';
import { COORDS, AV_COLORS } from '../constants';
import { isOverdue, initials, fmtDate } from '../utils';

const PRIO_COLOR = { alta:'#ef4444', media:'#f59e0b', baixa:'#10b981' };

export default function ConsolidatedTable({ tasks, onOpen }) {
  const [drawer, setDrawer] = useState(null); // { name, filter }

  const stats = Object.keys(COORDS).map(name => {
    const mine = tasks.filter(t => t.resp === name);
    return {
      name,
      total: mine.length,
      ni:    mine.filter(t => t.status === 'nao_iniciado').length,
      an:    mine.filter(t => t.status === 'andamento').length,
      co:    mine.filter(t => t.status === 'concluido').length,
      at:    mine.filter(t => isOverdue(t)).length,
    };
  });

  const openDrawer = (name, filter) => {
    if (drawer?.name === name && drawer?.filter === filter) {
      setDrawer(null);
    } else {
      setDrawer({ name, filter });
    }
  };

  const drawerTasks = drawer ? tasks.filter(t => {
    if (t.resp !== drawer.name) return false;
    if (drawer.filter === 'atrasado') return isOverdue(t);
    if (drawer.filter === 'nao_iniciado') return t.status === 'nao_iniciado';
    if (drawer.filter === 'andamento')    return t.status === 'andamento';
    if (drawer.filter === 'concluido')    return t.status === 'concluido';
    return true;
  }) : [];

  const FILTER_LABELS = { nao_iniciado:'Não Iniciado', andamento:'Em Andamento', concluido:'Concluído', atrasado:'Atrasadas' };
  const FILTER_COLORS = { nao_iniciado:'#6b7a99', andamento:'#f97316', concluido:'#10b981', atrasado:'#ef4444' };

  return (
    <div style={S.wrap}>
      <div style={S.tableHead}>
        <div style={S.sectionTitle}>📊 Visão por Coordenador</div>
      </div>
      <div style={S.tableWrap}>
        <table style={S.table}>
          <thead>
            <tr>
              {['Coordenador','Célula','Total','Não Iniciado','Andamento','Concluído','Atrasado'].map(h => (
                <th key={h} style={S.th}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {stats.map(s => {
              const avColor = AV_COLORS[COORDS[s.name]?.av || 'av-X'];
              return (
                <tr key={s.name} style={S.tr}>
                  <td style={S.td}>
                    <div style={S.coordCell}>
                      <div style={{...S.avatar,background:avColor}}>{initials(s.name)}</div>
                      <div>
                        <div style={S.coordName}>{s.name}</div>
                        <div style={S.coordSub}>{COORDS[s.name].cell}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{...S.td,color:'#6b7a99',fontSize:13}}>{COORDS[s.name].cell}</td>
                  <td style={{...S.td,textAlign:'center'}}>
                    <span onClick={()=>openDrawer(s.name,'todos')} style={{...S.pill,background:'rgba(139,92,246,.12)',color:'#8b5cf6',cursor:'pointer'}}>{s.total||'—'}</span>
                  </td>
                  <td style={{...S.td,textAlign:'center'}}>
                    <span onClick={()=>openDrawer(s.name,'nao_iniciado')} style={{...S.pill,background:'rgba(245,158,11,.12)',color:'#f59e0b',cursor:'pointer'}}>{s.ni||'—'}</span>
                  </td>
                  <td style={{...S.td,textAlign:'center'}}>
                    <span onClick={()=>openDrawer(s.name,'andamento')} style={{...S.pill,background:'rgba(249,115,22,.12)',color:'#f97316',cursor:'pointer'}}>{s.an||'—'}</span>
                  </td>
                  <td style={{...S.td,textAlign:'center'}}>
                    <span onClick={()=>openDrawer(s.name,'concluido')} style={{...S.pill,background:'rgba(16,185,129,.12)',color:'#10b981',cursor:'pointer'}}>{s.co||'—'}</span>
                  </td>
                  <td style={{...S.td,textAlign:'center'}}>
                    <span onClick={()=>openDrawer(s.name,'atrasado')} style={{...S.pill,background:'rgba(239,68,68,.12)',color:'#ef4444',cursor:'pointer'}}>{s.at||'—'}</span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* DRAWER */}
      {drawer && (
        <div style={S.drawer}>
          <div style={S.drawerHead}>
            <div style={S.drawerTitle}>
              <div style={{...S.avatar2, background: AV_COLORS[COORDS[drawer.name]?.av||'av-X']}}>{initials(drawer.name)}</div>
              <span>{drawer.name} · <span style={{color: FILTER_COLORS[drawer.filter] || '#6b7a99'}}>{FILTER_LABELS[drawer.filter] || 'Todas'}</span></span>
            </div>
            <button style={S.drawerClose} onClick={()=>setDrawer(null)}>✕</button>
          </div>
          <div style={S.drawerGrid}>
            {drawerTasks.length === 0 ? (
              <div style={S.drawerEmpty}>Nenhuma atividade nesta categoria.</div>
            ) : drawerTasks.map(t => (
              <div key={t.id} style={{...S.drawerCard, borderLeftColor: PRIO_COLOR[t.prio]}} onClick={()=>onOpen(t.id)}>
                <div style={S.drawerCardTitle}>{t.title}</div>
                <div style={S.drawerCardMeta}>
                  <span style={{...S.miniTag, background:PRIO_COLOR[t.prio]+'18', color:PRIO_COLOR[t.prio]}}>{t.prio.toUpperCase()}</span>
                  <span style={{fontSize:11,color: isOverdue(t)?'#ef4444':'#9aa3b8'}}>📅 {fmtDate(t.deadline)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const S = {
  wrap: { background:'#fff',border:'1px solid rgba(0,0,0,.08)',borderRadius:18,overflow:'hidden',marginBottom:28 },
  tableHead: { padding:'18px 22px 0',display:'flex',alignItems:'center',justifyContent:'space-between' },
  sectionTitle: { fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:700,textTransform:'uppercase',letterSpacing:'1px',color:'#1a2035',padding:'4px 0 14px' },
  tableWrap: { overflowX:'auto' },
  table: { width:'100%',borderCollapse:'collapse',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  th: { padding:'12px 16px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'1px',color:'#6b7a99',borderBottom:'1px solid rgba(0,0,0,.06)',background:'#f5f7fb',whiteSpace:'nowrap' },
  tr: { transition:'background .15s' },
  td: { padding:'14px 16px',borderBottom:'1px solid rgba(0,0,0,.04)',verticalAlign:'middle' },
  coordCell: { display:'flex',alignItems:'center',gap:10 },
  avatar: { width:30,height:30,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:11,fontWeight:700,flexShrink:0 },
  coordName: { fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:600,color:'#1a2035' },
  coordSub:  { fontSize:11,color:'#9aa3b8' },
  pill: { fontSize:13,fontWeight:700,padding:'4px 12px',borderRadius:20,display:'inline-block',transition:'transform .15s' },
  drawer: { borderTop:'1px solid rgba(0,0,0,.08)',background:'#f5f7fb' },
  drawerHead: { display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 20px',borderBottom:'1px solid rgba(0,0,0,.06)',background:'#eaecf4' },
  drawerTitle: { display:'flex',alignItems:'center',gap:10,fontFamily:"'Clash Display',sans-serif",fontSize:14,fontWeight:700,color:'#1a2035' },
  avatar2: { width:26,height:26,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:10,fontWeight:700 },
  drawerClose: { width:28,height:28,borderRadius:7,border:'1px solid rgba(0,0,0,.1)',background:'#fff',color:'#6b7a99',fontSize:14,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center' },
  drawerGrid: { display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:10,padding:'16px 20px' },
  drawerCard: { background:'#fff',border:'1px solid rgba(0,0,0,.06)',borderLeft:'3px solid',borderRadius:11,padding:'13px 14px',cursor:'pointer',transition:'all .18s',fontFamily:"'Plus Jakarta Sans',sans-serif" },
  drawerCardTitle: { fontFamily:"'Clash Display',sans-serif",fontSize:12.5,fontWeight:600,lineHeight:1.35,marginBottom:8,color:'#1a2035' },
  drawerCardMeta:  { display:'flex',alignItems:'center',justifyContent:'space-between',gap:6 },
  miniTag: { fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:20 },
  drawerEmpty: { color:'#9aa3b8',fontSize:13,textAlign:'center',padding:'20px',gridColumn:'1/-1' },
};
