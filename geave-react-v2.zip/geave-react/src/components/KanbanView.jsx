import React from 'react';
import TaskCard from './TaskCard';
import { isOverdue } from '../utils';

const COLS = [
  { key:'atrasado',    label:'Atrasado',    color:'#ef4444', icon:'⚠️' },
  { key:'nao_iniciado',label:'Não Iniciado',color:'#f59e0b', icon:'⏸' },
  { key:'andamento',   label:'Em Andamento',color:'#3b82f6', icon:'🔄' },
  { key:'concluido',   label:'Concluído',   color:'#10b981', icon:'✅' },
];

export default function KanbanView({ tasks, role, onOpen, onEdit, onDelete, onNotify }) {
  const getCol = (key) => {
    if (key === 'atrasado') return tasks.filter(t => isOverdue(t));
    return tasks.filter(t => t.status === key && !isOverdue(t));
  };

  return (
    <div style={S.board}>
      {COLS.map(col => {
        const list = getCol(col.key);
        return (
          <div key={col.key} style={S.col}>
            <div style={S.colHead}>
              <div style={S.colLeft}>
                <div style={{...S.colDot, background:col.color}} />
                <span style={S.colLabel}>{col.icon} {col.label}</span>
              </div>
              <span style={{...S.colCount, background:col.color+'18', color:col.color}}>{list.length}</span>
            </div>
            <div>
              {list.length === 0 ? (
                <div style={S.empty}>Nenhuma atividade</div>
              ) : list.map(t => (
                <TaskCard key={t.id} task={t} role={role} onOpen={onOpen} onEdit={onEdit} onDelete={onDelete} onNotify={onNotify} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

const S = {
  board: { display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:16,fontFamily:"'Plus Jakarta Sans',sans-serif" },
  col:   { background:'#f5f7fb',borderRadius:16,padding:14,minHeight:180 },
  colHead: { display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14 },
  colLeft: { display:'flex',alignItems:'center',gap:7 },
  colDot:  { width:8,height:8,borderRadius:'50%' },
  colLabel: { fontFamily:"'Clash Display',sans-serif",fontSize:13,fontWeight:600,color:'#1a2035' },
  colCount: { fontSize:12,fontWeight:700,padding:'3px 10px',borderRadius:20 },
  empty: { textAlign:'center',color:'#9aa3b8',fontSize:13,padding:'28px 0' },
};
