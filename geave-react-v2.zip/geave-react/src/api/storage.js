import { JSONBIN_KEY, JSONBIN_URL } from '../constants';

let _saveTimer = null;

export async function loadAllData() {
  let tasksData = [], nextIdData = 1, histData = {}, commData = {};
  try {
    const r = await fetch(`${JSONBIN_URL}/latest`, {
      headers: { 'X-Master-Key': JSONBIN_KEY },
    });
    if (r.ok) {
      const j = await r.json();
      const d = j.record || {};
      if (Array.isArray(d.tasks))            tasksData  = d.tasks;
      if (typeof d.nextId === 'number')      nextIdData = d.nextId;
      if (d.history_log && typeof d.history_log === 'object') histData = d.history_log;
      if (d.comments    && typeof d.comments === 'object')    commData = d.comments;
    }
  } catch (e) {
    console.warn('Erro ao carregar:', e);
  }
  return { tasksData, nextIdData, histData, commData };
}

export function scheduleSave(tasks, nextId, history_log, comments) {
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(async () => {
    try {
      await fetch(JSONBIN_URL, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': JSONBIN_KEY,
          'X-Bin-Versioning': 'false',
        },
        body: JSON.stringify({ tasks, nextId, history_log, comments }),
      });
    } catch (e) {
      console.warn('Erro ao salvar:', e);
    }
  }, 400);
}
