import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { loadAllData, scheduleSave } from '../api/storage';

const AppContext = createContext(null);

const SESSION_KEY  = 'geave_session';
const REMEMBER_KEY = 'geave_remember';

const getSession   = () => { try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch { return null; } };
const setSession   = (s) => localStorage.setItem(SESSION_KEY, JSON.stringify(s));
const clearSession = ()  => localStorage.removeItem(SESSION_KEY);
const isRemembered = ()  => localStorage.getItem(REMEMBER_KEY) === '1';
const setRemember  = (v) => v ? localStorage.setItem(REMEMBER_KEY, '1') : localStorage.removeItem(REMEMBER_KEY);

export function AppProvider({ children }) {
  const [tasks,      setTasks]      = useState([]);
  const [nextId,     setNextId]     = useState(1);
  const [historyLog, setHistoryLog] = useState({});
  const [comments,   setComments]  = useState({});
  const [role,       setRole]       = useState(null);
  const [coordName,  setCoordName]  = useState(null);
  const [appLoading, setAppLoading] = useState(false);
  const [toast,      setToast]      = useState(null);

  // Use refs to always have fresh values in callbacks
  const stateRef = useRef({ tasks, nextId, historyLog, comments });
  useEffect(() => { stateRef.current = { tasks, nextId, historyLog, comments }; }, [tasks, nextId, historyLog, comments]);

  // ─── TOAST ───────────────────────────────────────────
  const toastTimer = useRef(null);
  const showToast = useCallback((msg, color = '#10b981') => {
    setToast({ msg, color });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  // ─── PERSIST ─────────────────────────────────────────
  const persist = useCallback((t, nid, hl, cm) => {
    scheduleSave(t, nid, hl, cm);
  }, []);

  // ─── HISTORY ─────────────────────────────────────────
  const addHistoryEntry = useCallback((taskId, action, currentRole, currentCoordName, currentHL) => {
    const who = currentRole === 'gestao' ? 'Claudia (Gestão)' : (currentCoordName || 'Coordenador');
    const entry = { ts: new Date().toISOString(), who, action };
    const updated = {
      ...currentHL,
      [taskId]: [entry, ...(currentHL[taskId] || [])].slice(0, 20),
    };
    setHistoryLog(updated);
    return updated;
  }, []);

  // ─── LOGIN / LOGOUT ───────────────────────────────────
  const startApp = useCallback(async (r, cName) => {
    setAppLoading(true);
    const { tasksData, nextIdData, histData, commData } = await loadAllData();
    setTasks(tasksData);
    setNextId(nextIdData);
    setHistoryLog(histData);
    setComments(commData);
    setRole(r);
    setCoordName(cName);
    setAppLoading(false);
  }, []);

  const login = useCallback(async (r, cName, remember) => {
    setRemember(remember);
    setSession({ role: r, coordName: cName });
    await startApp(r, cName);
  }, [startApp]);

  const logout = useCallback(() => {
    clearSession();
    setRemember(false);
    setRole(null);
    setCoordName(null);
    setTasks([]);
    setHistoryLog({});
    setComments({});
  }, []);

  // Check saved session on mount
  useEffect(() => {
    const sess = getSession();
    if (sess?.role === 'gestao' && isRemembered()) {
      startApp('gestao', null);
    } else if (sess?.role === 'coordenador' && sess?.coordName && isRemembered()) {
      startApp('coordenador', sess.coordName);
    }
  }, []); // eslint-disable-line

  // ─── TASKS CRUD ───────────────────────────────────────
  const createTask = useCallback((data) => {
    const { tasks: t, nextId: nid, historyLog: hl, comments: cm } = stateRef.current;
    const newTask = { id: nid, ...data };
    const newTasks = [...t, newTask];
    const entry = { ts: new Date().toISOString(), who: 'Claudia (Gestão)', action: 'Atividade criada' };
    const newHL = { ...hl, [newTask.id]: [entry, ...(hl[newTask.id] || [])] };
    const newNid = nid + 1;
    setTasks(newTasks);
    setNextId(newNid);
    setHistoryLog(newHL);
    persist(newTasks, newNid, newHL, cm);
    return newTask;
  }, [persist]);

  const updateTask = useCallback((id, data, currentRole, currentCoordName) => {
    const { tasks: t, nextId: nid, historyLog: hl, comments: cm } = stateRef.current;
    const old = t.find(x => x.id === id);
    const changes = [];
    if (old.status   !== data.status)   changes.push(`Status: ${old.status} → ${data.status}`);
    if (old.prio     !== data.prio)     changes.push(`Prioridade: ${old.prio} → ${data.prio}`);
    if (old.deadline !== data.deadline) changes.push(`Prazo: ${old.deadline} → ${data.deadline}`);
    if (old.resp     !== data.resp)     changes.push(`Responsável: ${old.resp} → ${data.resp}`);
    const action = changes.length ? 'Editado: ' + changes.join(' | ') : 'Atividade atualizada';
    const newTasks = t.map(x => x.id === id ? { ...x, ...data } : x);
    const newHL = addHistoryEntry(id, action, currentRole, currentCoordName, hl);
    setTasks(newTasks);
    persist(newTasks, nid, newHL, cm);
  }, [persist, addHistoryEntry]);

  const deleteTask = useCallback((id) => {
    const { tasks: t, nextId: nid, historyLog: hl, comments: cm } = stateRef.current;
    const newTasks = t.filter(x => x.id !== id);
    setTasks(newTasks);
    persist(newTasks, nid, hl, cm);
  }, [persist]);

  const updateStatus = useCallback((id, status, currentRole, currentCoordName) => {
    const { tasks: t, nextId: nid, historyLog: hl, comments: cm } = stateRef.current;
    const old = t.find(x => x.id === id);
    const action = `Status: ${old?.status} → ${status}`;
    const newTasks = t.map(x => x.id === id ? { ...x, status } : x);
    const newHL = addHistoryEntry(id, action, currentRole, currentCoordName, hl);
    setTasks(newTasks);
    persist(newTasks, nid, newHL, cm);
  }, [persist, addHistoryEntry]);

  const addComment = useCallback((taskId, text, currentRole, currentCoordName) => {
    const { tasks: t, nextId: nid, historyLog: hl, comments: cm } = stateRef.current;
    const who = currentRole === 'gestao' ? 'Claudia (Gestão)' : (currentCoordName || 'Coordenador');
    const entry = { ts: new Date().toISOString(), who, text };
    const newComments = { ...cm, [taskId]: [...(cm[taskId] || []), entry] };
    const action = `Comentário: "${text.slice(0, 40)}${text.length > 40 ? '…' : ''}"`;
    const newHL = addHistoryEntry(taskId, action, currentRole, currentCoordName, hl);
    setComments(newComments);
    persist(t, nid, newHL, newComments);
  }, [persist, addHistoryEntry]);

  return (
    <AppContext.Provider value={{
      tasks, nextId, historyLog, comments,
      role, coordName, appLoading,
      toast, showToast,
      createTask, updateTask, deleteTask, updateStatus, addComment,
      login, logout,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
