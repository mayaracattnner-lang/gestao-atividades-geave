import React, { useState, useMemo } from 'react';
import { useApp } from './context/AppContext';
import LoginScreen from './components/LoginScreen';
import Header from './components/Header';
import StatsGrid from './components/StatsGrid';
import WeekBox from './components/WeekBox';
import ConsolidatedTable from './components/ConsolidatedTable';
import Toolbar from './components/Toolbar';
import KanbanView from './components/KanbanView';
import TableView from './components/TableView';
import TaskModal from './components/TaskModal';
import DetailModal from './components/DetailModal';
import DeleteModal from './components/DeleteModal';
import Toast from './components/Toast';
import { isOverdue, prioOrder } from './utils';

export default function App() {
  const { role, coordName, tasks, appLoading } = useApp();

  const [view,      setView]     = useState('kanban');
  const [filters,   setFilters]  = useState({ search:'', coord:'', status:'', prio:'', dateFrom:'', dateTo:'', sort:'prio' });
  const [editId,    setEditId]   = useState(null);
  const [showEdit,  setShowEdit] = useState(false);
  const [detailId,  setDetailId] = useState(null);
  const [deleteId,  setDeleteId] = useState(null);

  // Tasks visible to this user
  const baseTasks = useMemo(() => {
    if (role === 'coordenador' && coordName) return tasks.filter(t => t.resp === coordName);
    return tasks;
  }, [tasks, role, coordName]);

  // Apply filters + sort
  const filtered = useMemo(() => {
    let res = [...baseTasks];
    if (filters.coord)    res = res.filter(t => t.resp === filters.coord);
    if (filters.status === 'atrasado') {
      res = res.filter(t => isOverdue(t));
    } else if (filters.status) {
      res = res.filter(t => t.status === filters.status);
    }
    if (filters.prio)     res = res.filter(t => t.prio === filters.prio);
    if (filters.dateFrom) res = res.filter(t => t.deadline >= filters.dateFrom);
    if (filters.dateTo)   res = res.filter(t => t.deadline <= filters.dateTo);
    if (filters.search) {
      const q = filters.search.toLowerCase();
      res = res.filter(t => t.title.toLowerCase().includes(q) || (t.desc||'').toLowerCase().includes(q) || t.resp.toLowerCase().includes(q));
    }
    res.sort((a, b) => {
      if (filters.sort === 'prazo')   return (a.deadline||'') > (b.deadline||'') ? 1 : -1;
      if (filters.sort === 'criacao') return a.id - b.id;
      // default: prio, atrasado first
      if (isOverdue(a) !== isOverdue(b)) return isOverdue(a) ? -1 : 1;
      return prioOrder(a.prio) - prioOrder(b.prio);
    });
    return res;
  }, [baseTasks, filters]);

  if (!role) return <><LoginScreen /><Toast /></>;

  if (appLoading) return (
    <div style={loadStyle}>
      <div style={spinner} />
      <div style={{color:'#6b7a99',fontSize:14,fontFamily:"'Plus Jakarta Sans',sans-serif"}}>Carregando dados…</div>
    </div>
  );

  return (
    <div style={{ background:'#eef2f7', minHeight:'100vh', fontFamily:"'Plus Jakarta Sans',sans-serif" }}>
      <Header view={view} setView={setView} />

      <main style={{ maxWidth:1600, margin:'0 auto', padding:'28px 28px 80px' }}>
        {/* Stats — gestão vê todos, coord vê só os seus */}
        <StatsGrid tasks={baseTasks} />

        {/* Esta Semana */}
        <WeekBox tasks={baseTasks} onOpen={setDetailId} />

        {/* Tabela consolidada — só gestão */}
        {role === 'gestao' && <ConsolidatedTable tasks={tasks} onOpen={setDetailId} />}

        {/* Toolbar */}
        <Toolbar
          role={role}
          filters={filters}
          setFilters={setFilters}
          onNew={() => { setEditId(null); setShowEdit(true); }}
          filteredTasks={filtered}
        />

        {/* Kanban / Tabela */}
        {view === 'kanban' ? (
          <KanbanView
            tasks={filtered}
            role={role}
            onOpen={setDetailId}
            onEdit={id => { setEditId(id); setShowEdit(true); }}
            onDelete={setDeleteId}
            onNotify={setDetailId}
          />
        ) : (
          <TableView
            tasks={filtered}
            role={role}
            onOpen={setDetailId}
            onEdit={id => { setEditId(id); setShowEdit(true); }}
            onDelete={setDeleteId}
            onNotify={setDetailId}
          />
        )}
      </main>

      {showEdit && (
        <TaskModal taskId={editId} onClose={() => { setShowEdit(false); setEditId(null); }} />
      )}
      {detailId !== null && (
        <DetailModal
          taskId={detailId}
          onClose={() => setDetailId(null)}
          onEdit={id => { setEditId(id); setShowEdit(true); setDetailId(null); }}
        />
      )}
      {deleteId !== null && (
        <DeleteModal taskId={deleteId} onClose={() => setDeleteId(null)} />
      )}

      <Toast />
    </div>
  );
}

const loadStyle = { display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',gap:16 };
const spinner   = { width:40,height:40,border:'4px solid #e2e8f0',borderTopColor:'#3b82f6',borderRadius:'50%',animation:'spin .8s linear infinite' };
