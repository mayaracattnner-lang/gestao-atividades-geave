// ─── AUTH ───────────────────────────────────────────────
export const GESTAO_EMAIL = 'claudia.armagnat@gps-pamcary.com.br';
export const GESTAO_PASS  = 'Pam26';
export const COORD_PASS   = 'Pam27';
export const CLAUDIA_WA   = '5511984809711';

export const COORD_EMAILS = {
  'arnaldo.honorato@gps-pamcary.com.br':  'Arnaldo',
  'ducineide.silva@gps-pamcary.com.br':   'Neide',
  'cibele.dourado@gps-pamcary.com.br':    'Cibele',
  'mara.napoli@gps-pamcary.com.br':       'Mara',
  'felipe.pandori@gps-pamcary.com.br':    'Felipe',
  'mayara.batista@gps-pamcary.com.br':    'Mayara',
};

export const COORDS = {
  Arnaldo: { cell: 'Célula Property',   email: 'arnaldo.honorato@gps-pamcary.com.br',  av: 'av-A', wa: '5511975022468' },
  Neide:   { cell: 'Célula Caminhão',   email: 'ducineide.silva@gps-pamcary.com.br',    av: 'av-N', wa: '5511973663357' },
  Cibele:  { cell: 'Célula Passeio',    email: 'cibele.dourado@gps-pamcary.com.br',     av: 'av-C', wa: '5511986963231' },
  Mara:    { cell: 'Célula Pós Vendas', email: 'mara.napoli@gps-pamcary.com.br',        av: 'av-M', wa: '5511937201242' },
  Felipe:  { cell: 'Zeba',              email: 'felipe.pandori@gps-pamcary.com.br',     av: 'av-F', wa: '5511947486182' },
  Mayara:  { cell: 'BI',                email: 'mayara.batista@gps-pamcary.com.br',     av: 'av-Y', wa: '5511983267955' },
};

// ─── JSONBIN ────────────────────────────────────────────
export const JSONBIN_KEY = '$2a$10$hqaSQJ5qznqQSSJ7r0rxPe.T7UivZxHYVqCk9FV/DKVRiafZarVrC';
export const JSONBIN_BIN = '69aedad443b1c97be9c53730';
export const JSONBIN_URL = `https://api.jsonbin.io/v3/b/${JSONBIN_BIN}`;

// ─── AVATAR COLORS ──────────────────────────────────────
export const AV_COLORS = {
  'av-A': '#3b82f6',
  'av-N': '#8b5cf6',
  'av-C': '#06b6d4',
  'av-M': '#f97316',
  'av-F': '#10b981',
  'av-Y': '#ec4899',
  'av-X': '#6b7a99',
};
